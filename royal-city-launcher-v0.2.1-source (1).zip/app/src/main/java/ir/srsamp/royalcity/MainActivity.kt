package ir.srsamp.royalcity

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val gold = Color.rgb(220, 180, 91)
    private lateinit var status: TextView
    private lateinit var nickname: EditText
    private val folderRequest = 41
    private val clientPackage = "com.kurdish.roleplay"
    private val prefs by lazy { getSharedPreferences("royal", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8,8,8)
        window.navigationBarColor = Color.rgb(8,8,8)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 24, 26, 24)
            setBackgroundColor(Color.rgb(10,10,10))
        }
        root.addView(text("♛", 48, gold, true), matchWrap())
        root.addView(text("ROYAL CITY", 30, gold, true), matchWrap())
        root.addView(text("ROLEPLAY • ANDROID", 13, Color.LTGRAY, false), matchWrap())
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 20, 18, 20)
            setBackgroundColor(Color.rgb(25,25,25))
        }
        root.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })
        panel.addView(text("Srsamp.ir : 7777", 18, gold, true), matchWrap())
        nickname = EditText(this).apply {
            hint = "نام_فامیلی"; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setPadding(12, 12, 12, 12); setBackgroundColor(Color.rgb(42,42,42))
            setText(prefs.getString("nickname", ""))
        }
        panel.addView(nickname, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 20 })
        val choose = Button(this).apply {
            text = "انتخاب پوشه تنظیمات کلاینت"
            setTextColor(Color.BLACK); setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold))
        }
        panel.addView(choose, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        choose.setOnClickListener { chooseConfigFolder() }
        val play = Button(this).apply {
            text = "ذخیره تنظیمات و اجرای کلاینت"
            setTextColor(Color.BLACK); setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold))
        }
        panel.addView(play, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        status = text("پوشه تنظیمات کلاینت را انتخاب کن.", 13, gold, false)
        panel.addView(status, matchWrap())
        play.setOnClickListener { saveAndLaunch() }
        setContentView(root)
        checkManifest()
    }

    private fun chooseConfigFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, folderRequest)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == folderRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(uri, flags)
            prefs.edit().putString("config_tree", uri.toString()).apply()
            status.text = "پوشه انتخاب شد."
        }
    }

    private fun saveAndLaunch() {
        val nick = nickname.text.toString().trim()
        if (nick.isBlank()) { status.text = "ابتدا نام بازیکن را وارد کن."; return }
        val tree = prefs.getString("config_tree", null)
        if (tree == null) { status.text = "اول پوشه SAMP را انتخاب کن."; return }
        try {
            val dir = DocumentFile.fromTreeUri(this, android.net.Uri.parse(tree))
                ?: throw Exception("folder")
            val ini = "[client]\\nname=$nick\\nhost=Srsamp.ir\\nport=7777\\npassword=\\n"
            val file = dir.findFile("settings.ini") ?: dir.createFile("text/plain", "settings.ini")
                ?: throw Exception("file")
            contentResolver.openOutputStream(file.uri, "wt")!!.bufferedWriter().use { it.write(ini) }
            prefs.edit().putString("nickname", nick).apply()
            val launch = packageManager.getLaunchIntentForPackage(clientPackage)
            if (launch == null) {
                status.text = "تنظیمات ذخیره شد؛ کلاینت سازگار نصب نیست."
                return
            }
            status.text = "تنظیمات ذخیره شد؛ در حال اجرای کلاینت…"
            startActivity(launch)
        } catch (e: Exception) {
            status.text = "ذخیره نشد. پوشه SAMP را دوباره انتخاب کن."
        }
    }

    private fun checkManifest() {
        thread {
            val msg = try {
                val c = URL("https://srsamp.ir/royal-launcher/manifest.json").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() }); c.disconnect()
                "لانچر آماده • نسخه ${j.optString("version", "؟")}"
            } catch (_: Exception) { "تنظیمات سرور فعلاً در دسترس نیست" }
            runOnUiThread { status.text = msg }
        }
    }
    private fun text(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); gravity=Gravity.CENTER
        if (bold) typeface=Typeface.DEFAULT_BOLD
        setPadding(0,6,0,6)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
