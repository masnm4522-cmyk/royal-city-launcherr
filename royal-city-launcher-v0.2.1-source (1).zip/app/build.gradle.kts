plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
dependencies {
    implementation("androidx.documentfile:documentfile:1.0.1")
}
android {
    namespace = "ir.srsamp.royalcity"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.srsamp.royalcity"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
