Royal City Launcher v0.2.1

امکانات اضافه‌شده:
- انتخاب پوشه تنظیمات کلاینت با پنجره امن Android Storage Access Framework
- نوشتن settings.ini با nickname و host=Srsamp.ir و port=7777
- تلاش برای اجرای کلاینت نصب‌شده با package id: com.kurdish.roleplay

مهم:
- کلاینت هدف باید نصب باشد و دقیقاً از فایل تنظیمات در پوشه انتخابی با قالب گفته‌شده پشتیبانی کند.
- هنگام اولین اجرا، پوشه SAMP مربوط به کلاینت را انتخاب کن.
- این پروژه دیتای GTA یا فایل‌های خودرو را توزیع نمی‌کند.
- این سورس هنوز APK کامپایل‌شده نیست؛ در Android Studio با Gradle بساز.
